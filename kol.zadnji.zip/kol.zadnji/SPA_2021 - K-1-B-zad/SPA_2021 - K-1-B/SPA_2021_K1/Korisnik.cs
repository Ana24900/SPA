﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace SPA_2021_K1
{
    class Korisnik
    {
        public string ime, vrsta;
        public int posjeta;
        public double cijena;

        Korisnik next;
        public Korisnik(string i,int p,double c,string v)
        {
            this.ime = i;
            this.posjeta = p;
            this.cijena = c;
            this.vrsta = v;
            next = null;
        }
    }
    class NovaHash:Hashtable
    {
        
        public List<Korisnik> MaliKorisnik(char c,Hashtable ht)
        {
            List<Korisnik> lista = new List<Korisnik>();
            foreach(string a in ht.Keys)
            {
                Korisnik k = (Korisnik)ht[a];
                char b = a.ToLower()[0];
                if(c==b)
                {
                    lista.Add(k);
                }
            }
            return lista;
        }
    }
    class Visetable
    {
        public ArrayList[] pod;
        public Visetable()
        {
            pod = new ArrayList[5];
            for (int i= 0;i<5;i++)
            {
                pod[i]= new ArrayList();
            }
        }
        public int Kategorizcija(int a)
        {
            if (a < 10)
                return 0;
            if (a < 20)
                return 1;
            if (a < 30)
                return 2;
            if (a < 40)
                return 3;
            else
                return 4;

        }

        public void Umetanje(Korisnik k)
        {
            int i = Kategorizcija(k.posjeta);
            pod[i].Add(k);
        }
    }
}
