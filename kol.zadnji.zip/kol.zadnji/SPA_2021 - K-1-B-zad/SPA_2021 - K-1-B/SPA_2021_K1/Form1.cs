﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;

namespace SPA_2021_K1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        NovaHash ht = new NovaHash();
        Hashtable ponavljaci = new Hashtable();
        private void btnUcitaj_Click(object sender, EventArgs e)
        {
            ht.Clear();
            ponavljaci.Clear();
            string ime = "podaci.txt";
            if (!File.Exists(ime))
            {
                MessageBox.Show("datoteka ne postoji");
                return;
            }
            using (StreamReader sr = File.OpenText(ime))
            {
                string s;
                while ((s = sr.ReadLine()) != null)
                {
                    string[] pod = s.Split(';');
                    Korisnik k = new Korisnik(pod[0], int.Parse(pod[1]), double.Parse(pod[2]), pod[3]);
                    if (!ht.ContainsKey(pod[0]))
                    {
                        ht.Add(pod[0], k);
                    }
                    else
                    {
                        Korisnik a = (Korisnik)ht[pod[0]];
                        ht[pod[0]] = k;
                        ponavljaci.Add(pod[0], a);
                    }
                }
            }
            Ispis(true);
            UmetanjeK();
        }

        public void Ispis(bool t)
        {
            richTextBox1.Text = "";
            foreach (string a in ponavljaci.Keys)
            {
                Korisnik k = (Korisnik)ponavljaci[a];
                richTextBox1.AppendText(k.ime + " " + k.posjeta + " " + k.cijena + " " + k.vrsta + "\n");
            }
            richTextBox1.AppendText("\n KORISNICI VIDEOTEKE \n");
            foreach (string a in ht.Keys)
            {
                Korisnik k = (Korisnik)ht[a];
                richTextBox1.AppendText(k.ime + " " + k.posjeta + " " + k.cijena + " " + k.vrsta + "\n");
            }
            if (t == true)
            {
                foreach (string a in ht.Keys)
                {
                    listBox1.Items.Add(a);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = listBox1.Items[0].ToString();
            if (listBox1.SelectedIndex > -1)
            {
                a = listBox1.SelectedItem.ToString();
            }
            if (!ht.ContainsKey(a))
            {
                MessageBox.Show("korisnik ne postoji");
                return;
            }
            else
            {
                ht.Remove(a);
            }
            Ispis(false);
        }
        List<Korisnik> lista = new List<Korisnik>();
        public void IspisImena()
        {
            richTextBox1.Text = "";
            foreach (Korisnik k in lista)
            {
                richTextBox1.AppendText(k.ime + " " + k.posjeta + " " + k.cijena + " " + k.vrsta + "\n");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            lista.Clear();
            string a = textBox1.Text.ToLower();
            char c = a[0];
            lista = ht.MaliKorisnik(c, ht);
            IspisImena();
        }
        Visetable vt = new Visetable();
        public void IspisKat(int a)
        {
            richTextBox1.Text = "";
            int br = 0;
            foreach (ArrayList kat in vt.pod)
            {
                br++;
                if (br == a)
                {
                    if (kat.Count == 0)
                    {
                        continue;
                    }
                    richTextBox1.AppendText("\n KATEGORIJA " + br + "\n");
                    foreach (Korisnik k in kat)
                    {
                        richTextBox1.AppendText(k.ime + " " + k.posjeta + " " + k.cijena + " " + k.vrsta + "\n");
                    }
                }

            }

        }
        public void UmetanjeK()
        {
            for (int i = 0; i < 5; i++)
            {
                comboBox1.Items.Add("KATEGORIJA" +i);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {

            foreach(string c in ht.Keys)
            {
                Korisnik k = (Korisnik)ht[c];
                vt.Umetanje(k);
            }
            int a = 0;
            if (comboBox1.SelectedIndex > -1)
            {
                a = comboBox1.SelectedIndex;

            }
            IspisKat(a);
            


        }
        Dictionary<string,Korisnik> dic=new Dictionary<string,Korisnik>();
        public void IspisCijena()
        {
            richTextBox1.Text = "";
            foreach(string a in dic.Keys)
            {
                Korisnik k = dic[a];
                richTextBox1.AppendText("\n" + a.ToUpper() + "\n" + k.ime + " " + k.posjeta + " " + k.cijena + " " + k.vrsta + "\n");
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            foreach(string a in ht.Keys)
            {
                Korisnik k=(Korisnik)ht[a];
                if(!dic.ContainsKey(k.vrsta))
                {
                    dic.Add(k.vrsta, k);
                }
                else
                {
                    Korisnik b = dic[k.vrsta];
                    if(k.cijena>b.cijena)
                    {
                        dic[k.vrsta] = b;
                    }
                }
            }
            IspisCijena();
        }

        private void btnKraj_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
