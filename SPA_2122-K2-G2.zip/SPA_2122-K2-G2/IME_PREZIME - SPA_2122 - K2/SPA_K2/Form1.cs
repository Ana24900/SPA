﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SPA_K2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            //ovdje su ručno dodana tri čvora za test:
            //BinarnoStablo testStablo = new BinarnoStablo();
            //testStablo.Korijen = new Cvor(50);
            //testStablo.Korijen.Lijevi = new Cvor(25);
            //testStablo.Korijen.Desni = new Cvor(75);

            //testStablo.Crtaj(boxProstorZaCrtanje, 10);
        }

        /* Promjenom veličine forme, mijenja se veličina PictureBox */
        private void Form1_Resize(object sender, EventArgs e)
        {
            boxProstorZaCrtanje.Width = this.Width - 50;
            boxProstorZaCrtanje.Height = this.Height - 200;
            boxProstorZaCrtanje.Refresh();
            stablo.Crtaj(boxProstorZaCrtanje, 10);
        }

        BinarnoStablo stablo = new BinarnoStablo();

        private void btnUcitaj_Click(object sender, EventArgs e)
        {
            //string imeDatoteke = "";
            //using (StreamReader sr = File.OpenText(imeDatoteke))
            //{
            //    string linija;
            //    while ((linija = sr.ReadLine()) != null)
            //    {

            //    }
            //}

            //učitati stablo:

            //nakon što se učita stablo, ako je ispravno onda će se nacrtati kad pozovete metodu Crtaj:
            stablo.Crtaj(boxProstorZaCrtanje, 10);
        }

        private void btnBrisi_Click(object sender, EventArgs e)
        {
            //nakon brisanja slika se mora ispravno nacrtati
            //listBox se NE OSVJEŽAVA
            
        }

        private void btnGraf_Click(object sender, EventArgs e)
        {
            //Graf se ispisuje tako da se za svaki čvor ispišu njegovi podaci
            //te pregledan popis čvorova s kojima je povezan, npr:
            //123 Ante, susjedi:
            // - 124 Pero
            // - 125 Ana
            //primjer podataka ne odgovara stvarnim podacima iz zadatka


        }
    }
}
