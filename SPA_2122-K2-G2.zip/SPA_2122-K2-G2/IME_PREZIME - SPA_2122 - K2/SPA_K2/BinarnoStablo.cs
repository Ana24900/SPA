﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace SPA_K2
{
    class Cvor
    {
        //ne mijenjati postojeće varijable, možete dodati svoja svojstva
        public int Broj;
        public Cvor Lijevi, Desni;

        public int x, y;
        
        public Cvor(int broj)
        {
            Broj = broj;
            Lijevi = null;
            Desni = null;
            x = 0;
            y = 0;

        }
    }

    class BinarnoStablo
    {
        public Cvor Korijen;

        public BinarnoStablo()
        {
            Korijen = null;
        }


        /* Metode za crtanje - ne treba mijenjati */
        public void CitajXY(Cvor k, int x, ref int y, List<Cvor> cvorovi)
        {
            if (k != null)
            {
                x++; 
                CitajXY(k.Lijevi, x, ref y, cvorovi);
                y++; 
                k.x = x;
                k.y = y;
                cvorovi.Add(k);
                CitajXY(k.Desni, x, ref y, cvorovi);
            }
        }

        public void Crtaj(PictureBox pictureBox, int velicinaFonta)
        {
            List<Cvor> cvorovi = new List<Cvor>();
            int yy = 0;
            CitajXY(Korijen, 0, ref yy, cvorovi);

            Graphics g = pictureBox.CreateGraphics();
            g.Clear(Color.LightGray);
            Font vrstaFonta = new Font("Arial", velicinaFonta);
            SolidBrush drawBrush = new SolidBrush(Color.Black);
            foreach (Cvor k in cvorovi)
            {
                String drawString = k.Broj.ToString();
                
                int x = k.y * velicinaFonta * 2;
                int y = k.x * velicinaFonta * 3;

                g.DrawString(drawString, vrstaFonta, drawBrush, x, y);

                /* Crtanje */

                Cvor t = Korijen;
                Cvor r = null;
                while (t != null)
                {
                    r = t;
                    if (k.Broj < t.Broj)
                        t = t.Lijevi;
                    else
                        if (k.Broj > t.Broj)
                            t = t.Desni;
                    if (k.Broj == t.Broj)
                        break;
                }
                
                Pen p = new Pen(drawBrush);
                if (r != null && k != Korijen)
                {
                    
                    int x0 = r.y * velicinaFonta * 2;
                    int y0 = r.x * velicinaFonta * 3;
                    
                    g.DrawLine(p, x + velicinaFonta, y, x0 + velicinaFonta, y0 + velicinaFonta * 2);
                }
            }

        }

        /* Ostale metode - ovdje pišete svoje metode */        

    }
}
